// Online C compiler to run C program online
#include <stdio.h>

int main() {
    for(int i=0;i<10;i++){
        printf("i: %d",i);
    }
}